import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import Hls from "hls.js";

class App extends Component {
  state = {
    // url: "http://techslides.com/demos/sample-videos/small.mp4"
    url: "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8"
  };

  componentDidMount() {
    var video = document.getElementById("video");
    if (Hls.isSupported()) {
      var hls = new Hls();
      hls.loadSource(
      this.state.url
      );
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, function() {
        video.play();
      });
    }

    else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = this.state.url;
      video.addEventListener("loadedmetadata", function() {
        video.play();
      });
    }
  }

  render() {
    return (
      <div className="App">
        <video id = "video" height = "200" width = "400" controls />
      </div>
    );
  }
}

export default App;
